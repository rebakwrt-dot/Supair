package com.sunspear;

import net.fabricmc.api.ModInitializer;
import net.fabricmc.fabric.api.entity.event.v1.ServerLivingEntityEvents;
import net.fabricmc.fabric.api.event.lifecycle.v1.ServerTickEvents;
import net.minecraft.core.Registry;
import net.minecraft.core.registries.BuiltInRegistries;
import net.minecraft.core.registries.Registries;
import net.minecraft.resources.Identifier;
import net.minecraft.resources.ResourceKey;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.damagesource.DamageTypes;
import net.minecraft.world.entity.EquipmentSlotGroup;
import net.minecraft.world.entity.ai.attributes.AttributeModifier;
import net.minecraft.world.entity.ai.attributes.Attributes;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.Rarity;
import net.minecraft.world.item.component.ItemAttributeModifiers;

import java.util.HashMap;
import java.util.Map;
import java.util.UUID;

public class SunSpearMod implements ModInitializer {
    public static final String MOD_ID = "sunspear";
    public static Item SUN_SPEAR;

    /** Защита от рекурсии, пока мы сами наносим урон. */
    public static boolean dealingBonusDamage = false;

    private static final Map<UUID, ItemStack> lastStack = new HashMap<>();
    private static final Map<UUID, Integer> lastDamage = new HashMap<>();

    @Override
    public void onInitialize() {
        ResourceKey<Item> key = ResourceKey.create(Registries.ITEM, Identifier.fromNamespaceAndPath(MOD_ID, "sun_spear"));

        ItemAttributeModifiers attributes = ItemAttributeModifiers.builder()
                // 9 + 1 (кулак) = 10 урона
                .add(Attributes.ATTACK_DAMAGE,
                        new AttributeModifier(Item.BASE_ATTACK_DAMAGE_ID, 9.0, AttributeModifier.Operation.ADD_VALUE),
                        EquipmentSlotGroup.MAINHAND)
                // скорость атаки 1.4
                .add(Attributes.ATTACK_SPEED,
                        new AttributeModifier(Item.BASE_ATTACK_SPEED_ID, -2.6, AttributeModifier.Operation.ADD_VALUE),
                        EquipmentSlotGroup.MAINHAND)
                .build();

        SUN_SPEAR = Registry.register(BuiltInRegistries.ITEM, key,
                new SunSpearItem(new Item.Properties()
                        .setId(key)
                        .durability(2031)
                        .rarity(Rarity.EPIC)
                        .attributes(attributes)));

        // Пассивный «Заговор огня» + доп. урон 2 при обычном ударе
        ServerLivingEntityEvents.AFTER_DAMAGE.register((entity, source, baseDamage, damageTaken, blocked) -> {
            if (dealingBonusDamage || blocked) return;
            if (!source.is(DamageTypes.PLAYER_ATTACK)) return;
            if (!(source.getEntity() instanceof ServerPlayer player)) return;
            if (!player.getMainHandItem().is(SUN_SPEAR)) return;
            if (!(entity.level() instanceof ServerLevel level)) return;

            entity.igniteForSeconds(4);
            dealingBonusDamage = true;
            try {
                entity.invulnerableTime = 0;
                entity.hurtServer(level, level.damageSources().playerAttack(player), 2.0F);
            } finally {
                dealingBonusDamage = false;
            }
        });

        // Если у игрока больше половины HP — копьё не теряет прочность
        ServerTickEvents.END_SERVER_TICK.register(server -> {
            for (ServerPlayer p : server.getPlayerList().getPlayers()) {
                ItemStack stack = p.getMainHandItem();
                if (!stack.is(SUN_SPEAR)) {
                    lastStack.remove(p.getUUID());
                    continue;
                }
                int dmg = stack.getDamageValue();
                ItemStack prev = lastStack.get(p.getUUID());
                Integer prevDmg = lastDamage.get(p.getUUID());
                if (prev == stack && prevDmg != null && dmg > prevDmg && p.getHealth() > p.getMaxHealth() / 2.0F) {
                    stack.setDamageValue(prevDmg);
                    dmg = prevDmg;
                }
                lastStack.put(p.getUUID(), stack);
                lastDamage.put(p.getUUID(), dmg);
            }
        });
    }
}
