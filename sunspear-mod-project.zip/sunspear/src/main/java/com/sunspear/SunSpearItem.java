package com.sunspear;

import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.sounds.SoundSource;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.InteractionResult;
import net.minecraft.world.damagesource.DamageSource;
import net.minecraft.world.entity.EquipmentSlot;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.level.ClipContext;
import net.minecraft.world.level.Level;
import net.minecraft.world.phys.AABB;
import net.minecraft.world.phys.HitResult;
import net.minecraft.world.phys.Vec3;

public class SunSpearItem extends Item {
    private static final double RANGE = 48.0;
    private static final double BEAM_RADIUS = 1.0;
    private static final float BEAM_DAMAGE = 23.0F;
    private static final float BEAM_BONUS = 6.0F;
    private static final int COOLDOWN_TICKS = 100; // 5 сек
    private static final EquipmentSlot[] ARMOR =
            {EquipmentSlot.HEAD, EquipmentSlot.CHEST, EquipmentSlot.LEGS, EquipmentSlot.FEET};

    public SunSpearItem(Properties properties) {
        super(properties);
    }

    @Override
    public InteractionResult use(Level level, Player player, InteractionHand hand) {
        ItemStack stack = player.getItemInHand(hand);
        if (level instanceof ServerLevel server) {
            fireBeam(server, player, stack, hand);
        }
        return InteractionResult.SUCCESS;
    }

    private void fireBeam(ServerLevel level, Player player, ItemStack stack, InteractionHand hand) {
        Vec3 look = player.getLookAngle();
        Vec3 start = player.getEyePosition();
        Vec3 end = start.add(look.scale(RANGE));

        HitResult block = level.clip(new ClipContext(start, end,
                ClipContext.Block.COLLIDER, ClipContext.Fluid.NONE, player));
        if (block.getType() != HitResult.Type.MISS) {
            end = block.getLocation();
        }

        level.playSound(null, player.getX(), player.getY(), player.getZ(),
                SoundEvents.BLAZE_SHOOT, SoundSource.PLAYERS, 2.0F, 0.6F);

        // Визуал луча
        double length = end.subtract(start).length();
        for (double d = 1.0; d < length; d += 0.4) {
            Vec3 p = start.add(look.scale(d)).add(0, -0.25, 0);
            level.sendParticles(ParticleTypes.FLAME, p.x, p.y, p.z, 4, 0.35, 0.35, 0.35, 0.01);
            if (((int) (d / 0.4)) % 3 == 0) {
                level.sendParticles(ParticleTypes.LAVA, p.x, p.y, p.z, 1, 0.3, 0.3, 0.3, 0.0);
            }
        }

        // Урон по всем сущностям на линии
        final Vec3 rayEnd = end;
        AABB area = new AABB(start, rayEnd).inflate(BEAM_RADIUS + 1.0);
        for (LivingEntity target : level.getEntitiesOfClass(LivingEntity.class, area,
                e -> e != player && e.isAlive() && !e.isSpectator())) {
            if (target.getBoundingBox().inflate(BEAM_RADIUS).clip(start, rayEnd).isPresent()) {
                hit(level, player, target);
            }
        }

        // Прочность: тратится только если HP <= 50%
        if (player.getHealth() <= player.getMaxHealth() / 2.0F) {
            EquipmentSlot slot = hand == InteractionHand.MAIN_HAND ? EquipmentSlot.MAINHAND : EquipmentSlot.OFFHAND;
            stack.hurtAndBreak(1, player, slot);
        }
        player.getCooldowns().addCooldown(stack, COOLDOWN_TICKS);
    }

    private void hit(ServerLevel level, Player player, LivingEntity target) {
        // запоминаем прочность брони, чтобы луч её не ломал
        int[] saved = new int[ARMOR.length];
        for (int i = 0; i < ARMOR.length; i++) {
            saved[i] = target.getItemBySlot(ARMOR[i]).getDamageValue();
        }

        target.igniteForSeconds(10);
        SunSpearMod.dealingBonusDamage = true;
        try {
            target.invulnerableTime = 0;
            DamageSource src = level.damageSources().playerAttack(player); // броня срезает урон
            target.hurtServer(level, src, BEAM_DAMAGE + BEAM_BONUS);       // 23 + 6
        } finally {
            SunSpearMod.dealingBonusDamage = false;
        }

        for (int i = 0; i < ARMOR.length; i++) {
            ItemStack armor = target.getItemBySlot(ARMOR[i]);
            if (!armor.isEmpty() && armor.isDamageableItem()) {
                armor.setDamageValue(saved[i]);
            }
        }
    }
}
