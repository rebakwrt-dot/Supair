Требуется JDK 25.
1) Скачайте шаблон на https://fabricmc.net/develop/template/ (26.1.x) ИЛИ выполните в этой папке: gradle wrapper
2) ./gradlew build  -> build/libs/sunspear-1.0.0.jar в папку mods (нужен Fabric API)
Выдать копьё в тесте: /give @s sunspear:sun_spear
